﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.XPath;
using Xunit;

namespace $rootnamespace$
{
    public static class $fileinputname$
    {
        public class $fileinputname$_Input : List<string> //Define input type
        {
        }
        public static void $fileinputname$_Main()
        {
            var input = $fileinputname$_ReadInput();
            Console.WriteLine($"$fileinputname$ Part1: {$fileinputname$_Part1(input)}");
            Console.WriteLine($"$fileinputname$ Part2: {$fileinputname$_Part2(input)}");
        }

        public static $fileinputname$_Input $fileinputname$_ReadInput(string rawinput = "")
        {
            if (rawinput == "")
            {
                rawinput = new StreamReader("$fileinputname$\\$fileinputname$_input.txt").ReadToEnd();
            }

            var result = new $fileinputname$_Input();

            foreach (string line in rawinput.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.None).Select(s => s.Trim()))
            {
                 //result.Add(line);
            }

            return result;
        }


        public static int $fileinputname$_Part1($fileinputname$_Input input)
        {

            return 0;
        }

        public static int $fileinputname$_Part2($fileinputname$_Input input)
        {
            return 0;
        }


    }
    public class $fileinputname$_Test
    {
        [Theory]
        [InlineData("ABC", 0)]
        public static void $fileinputname$Part1Test(string rawinput, int expectedValue)
        {
            Assert.Equal(expectedValue, $fileinputname$.$fileinputname$_Part1($fileinputname$.$fileinputname$_ReadInput(rawinput)));
        }

        [Theory]
        [InlineData("ABC", 0)]
        public static void $fileinputname$Part2Test(string rawinput, int expectedValue)
        {
            Assert.Equal(expectedValue, $fileinputname$.$fileinputname$_Part2($fileinputname$.$fileinputname$_ReadInput(rawinput)));
        }
    }
}
